﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou
{
    public class MAJCarte
    {
       // Carte carte;
        public static void insererTresor(Carte carte, Tresor tresor)
        {
            carte.Cases[tresor.Position.Ligne, tresor.Position.Colonne].Tresor = tresor;
        }
    }
}
