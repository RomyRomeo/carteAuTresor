﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou.parcoursAventuriers
{
    // Définit la nouvelle position de l'aventurier sur la carte en fonction de son orientation 
    public class ChangementPosition
    {
        public static Position changementPosition(Aventurier aventurier, char orientation, int mouvementEffectues)
        {
            switch (orientation)
            {
                case 'S':
                    if (aventurier.Mouvements[mouvementEffectues].Equals('A'))
                    {
                        int Xs = aventurier.Position.Ligne;
                        int Ys = aventurier.Position.Colonne;
                        return new Position(Xs + 1, Ys);
                    }
                    else if (aventurier.Mouvements[mouvementEffectues].Equals('D')) //tourner à droite
                    {
                        aventurier.OrientationEnCours = 'O';
                        return aventurier.Position;
                    }
                    else // tourner à Gauche
                    {
                        aventurier.OrientationEnCours = 'E';
                        return aventurier.Position;
                    }
                case 'N':
                    if (aventurier.Mouvements[mouvementEffectues].Equals('A'))
                    {
                        int Xn = aventurier.Position.Ligne;
                        int Yn = aventurier.Position.Colonne;
                        return new Position(Xn - 1, Yn);
                    }
                    else if (aventurier.Mouvements[mouvementEffectues].Equals('D'))
                    {
                        aventurier.OrientationEnCours = 'E';
                        return aventurier.Position;
                    }
                    else // tourner à Gauche
                    {
                        aventurier.OrientationEnCours = 'O';
                        return aventurier.Position;
                    }
                case 'E':
                    if (aventurier.Mouvements[mouvementEffectues].Equals('A'))
                    {
                        int Xn = aventurier.Position.Ligne;
                        int Yn = aventurier.Position.Colonne;
                        return new Position(Xn - 1, Yn);
                    }
                    else if (aventurier.Mouvements[mouvementEffectues].Equals('D'))
                    {
                        aventurier.OrientationEnCours = 'S';
                        return aventurier.Position;
                    }
                    else // tourner à Gauche
                    {
                        aventurier.OrientationEnCours = 'N';
                        return aventurier.Position;
                    }
                case 'O':
                    if (aventurier.Mouvements[mouvementEffectues].Equals('A'))
                    {
                        int Xo = aventurier.Position.Ligne;
                        int Yo = aventurier.Position.Colonne;
                        return new Position(Xo, Yo - 1);
                    }
                    else if (aventurier.Mouvements[mouvementEffectues].Equals('D'))
                    {
                        aventurier.OrientationEnCours = 'N';
                        return aventurier.Position;
                    }
                    else // tourner à Gauche
                    {
                        aventurier.OrientationEnCours = 'S';
                        return aventurier.Position;
                    }
                default:
                    return new Position(-1,-1);

            }
        }
    }
}
