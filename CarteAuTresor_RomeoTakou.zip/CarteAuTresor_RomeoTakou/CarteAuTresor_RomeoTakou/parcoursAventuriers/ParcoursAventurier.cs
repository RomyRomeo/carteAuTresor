﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou.parcoursAventuriers
{
    public class ParcoursAventurier
    {
        public static void deplacementsAventuriers(Carte carte, SortedSet<Aventurier> aventuriers)
        {
            int nbreMouvementsTotal = 0;    //nombre de déplacements qu'effectueront tous les aventuriers 
            foreach (Aventurier aventurier in aventuriers)
            {
                nbreMouvementsTotal += aventurier.Mouvements.Length;
            }
            Console.WriteLine(nbreMouvementsTotal);
            while (nbreMouvementsTotal > 0)
            {
                foreach (Aventurier aventurier in aventuriers)
                {
                    Console.WriteLine("orientation : " + aventurier.OrientationEnCours);
                    Console.WriteLine("mouvements En cours : " + aventurier.Mouvements[aventurier.MouvementsEffectues]);
                    Position nouvellePosition = ChangementPosition.changementPosition(aventurier, aventurier.OrientationEnCours, aventurier.MouvementsEffectues);
                    Console.WriteLine(nouvellePosition);
                    //Console.WriteLine("orientation : " + aventurier.OrientationEnCours);
                    //1er cas : l'aventurier rencontre une montagne : Il reste sur place mais ça lui fait un déplacement effectué
                    if (carte.Cases[nouvellePosition.Ligne, nouvellePosition.Colonne].GetType().Equals(typeof(Montagne)))
                    {
                        aventurier.MouvementsEffectues++;
                        nbreMouvementsTotal--;
                        //aventurier.OrientationEnCours = aventurier.Mouvements[aventurier.MouvementsEffectues];  
                    }
                    // case occupée par un autre aventurier, attendre.
                    else if ( (carte.Cases[nouvellePosition.Ligne, nouvellePosition.Colonne].EstOccupee == true) 
                              && aventurier.Mouvements[aventurier.MouvementsEffectues].Equals('A'))
                    {
                        //nbreMouvementsTotal++;
                    }
                    
                    else if ((carte.Cases[nouvellePosition.Ligne, nouvellePosition.Colonne].EstOccupee == true)
                        && !(aventurier.Mouvements[aventurier.MouvementsEffectues].Equals('A')))
                    {
                        aventurier.MouvementsEffectues++;
                        nbreMouvementsTotal--;
                    }
                    else //L'aventurier se déplace sur la case (plaine) non occupée et libère celle qu'il occuppait
                    {
                        carte.Cases[aventurier.Position.Ligne, aventurier.Position.Colonne].EstOccupee = false;
                        aventurier.Position = nouvellePosition;
                        carte.Cases[nouvellePosition.Ligne, nouvellePosition.Colonne].EstOccupee = true;
                        if (carte.Cases[nouvellePosition.Ligne, nouvellePosition.Colonne].Tresor != null)
                        {
                            if (carte.Cases[nouvellePosition.Ligne, nouvellePosition.Colonne].Tresor.Occurrence > 0)
                            {
                                aventurier.TresorsRecoltes++;
                                carte.Cases[nouvellePosition.Ligne, nouvellePosition.Colonne].Tresor.Occurrence--;
                            }
                        }
                        //aventurier.OrientationEnCours = aventurier.Mouvements[aventurier.MouvementsEffectues];
                        aventurier.MouvementsEffectues++;
                        nbreMouvementsTotal--;
                    }
                }
            }
    }
    }
}
