﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou.parcoursAventuriers
{
    class ListeAventuriers
    {
        private SortedSet<Aventurier> listAventuriers = new SortedSet<Aventurier>(new AventurierComp());

        public ListeAventuriers() { }
        public void addAventurier(Aventurier aventurier)
        {
            listAventuriers.Add(aventurier);
        }
        internal SortedSet<Aventurier> ListAventuriers { get => listAventuriers; set => listAventuriers = value; }
    }
}
