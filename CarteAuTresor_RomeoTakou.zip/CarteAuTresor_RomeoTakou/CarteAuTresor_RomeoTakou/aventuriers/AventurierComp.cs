﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou.parcoursAventuriers
{
    public class AventurierComp : IComparer<Aventurier>
    {
        public int Compare(Aventurier av1, Aventurier av2)
        {
            return av1.PositionDansLaFiche.CompareTo(av2.PositionDansLaFiche);
        }
    }
}
