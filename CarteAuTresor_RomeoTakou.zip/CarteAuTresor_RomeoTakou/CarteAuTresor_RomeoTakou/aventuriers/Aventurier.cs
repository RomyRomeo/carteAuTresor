﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou
{
    public class Aventurier
    {
        private readonly String nom;
        private Position position;       // position de l'aventurier sur la carte
        private char orientationEnCours;
        private char[] mouvements;
        private readonly int positionDansLaFiche;     //ordre d'apparition dans la fiche d'entrée 
        private int tresorsRecoltes;
        private int mouvementsEffectues; 

        public Aventurier(string nom, Position position, char[] mouvements, int positionDansLaFiche)
        {
            this.nom = nom;
            this.position = position;
            this.mouvements = mouvements;
            this.positionDansLaFiche = positionDansLaFiche;
        }

        public string Nom => nom;

        public char OrientationEnCours { get => orientationEnCours; set => orientationEnCours = value; }
        public char[] Mouvements { get => mouvements; set => mouvements = value; }
        internal Position Position { get => position; set => position = value; }

        public int PositionDansLaFiche => positionDansLaFiche;

        public int TresorsRecoltes { get => tresorsRecoltes; set => tresorsRecoltes = value; }
        public int MouvementsEffectues { get => mouvementsEffectues; set => mouvementsEffectues = value; }
    }
}
