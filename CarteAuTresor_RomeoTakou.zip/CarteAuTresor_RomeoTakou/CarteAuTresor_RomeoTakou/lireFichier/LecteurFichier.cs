﻿using CarteAuTresor_RomeoTakou.cartographie;
using CarteAuTresor_RomeoTakou.parcoursAventuriers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CarteAuTresor_RomeoTakou.lireFichier
{
    public class LecteurFichier
    {
        private Carte carte;
        private ListeAventuriers listeAventuriers = new ListeAventuriers();
        private ListeMontagnes listeMontagnes = new ListeMontagnes();
        private ListeTresors listeTresors = new ListeTresors();
        

        public ListeTresors ListeTresors { get => listeTresors; set => listeTresors = value; }
        public Carte Carte { get => carte; set => carte = value; }
        internal ListeAventuriers ListeAventuriers { get => listeAventuriers; set => listeAventuriers = value; }
        internal ListeMontagnes ListeMontagnes { get => listeMontagnes; set => listeMontagnes = value; }

        public void lireFichier(String chemin)
        {
            using (StreamReader sr = new StreamReader(chemin))
            {
                int compteur = 1;
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.StartsWith("#"))
                    {
                        continue;
                    }
                    else
                    {
                        var lineValue = line.Split(new[] { Environment.NewLine, "-", " " }, StringSplitOptions.RemoveEmptyEntries);
                        if (lineValue.Length != 0)
                        {
                            if (lineValue[0].Equals("C"))
                            {
                                // création de la carte
                                int nombreDeligne = Int32.Parse(lineValue[2]);
                                int nombreDeColonne = Int32.Parse(lineValue[1]);
                                this.carte = new Carte(nombreDeligne, nombreDeColonne);
                            }
                            if (lineValue[0].Equals("M"))
                            {
                                //création d'une montagne
                                int ligne = Int32.Parse(lineValue[2]);
                                int colonne = Int32.Parse(lineValue[1]);
                                Montagne montagne = new Montagne(new Position(ligne, colonne));
                                this.listeMontagnes.addMontagne(montagne);
                            }
                            if (lineValue[0].Equals("T"))
                            {
                                // création d'un trésor
                                int ligne = Int32.Parse(lineValue[2]);
                                int colonne = Int32.Parse(lineValue[1]);
                                int occurrence = Int32.Parse(lineValue[3]);
                                Tresor tresor = new Tresor(new Position(ligne, colonne), occurrence);
                                this.listeTresors.addTresor(tresor);
                            }
                            if (lineValue[0].Equals("A"))
                            {
                                // création d'un aventurier
                                String nom = lineValue[1];
                                int ligne = Int32.Parse(lineValue[3]);
                                int colonne = Int32.Parse(lineValue[2]);
                                string orientationEnCours = lineValue[4];
                                char[] mouvements = lineValue[5].ToCharArray();
                                Aventurier aventurier = new Aventurier(nom, new Position(ligne, colonne), mouvements, compteur);
                                aventurier.OrientationEnCours = char.Parse(orientationEnCours);
                                this.listeAventuriers.addAventurier(aventurier);
                            }
                            compteur++;
                        }
                        
                    }
                }
                    
            }
        }
        
    }
}
