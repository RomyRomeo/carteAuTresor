﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou
{
    public class Montagne : Plaine
    {
        
        public Montagne(Position p)
        {
            this.position = p;
            this.estFranchissable = false;
        }
    }
}
