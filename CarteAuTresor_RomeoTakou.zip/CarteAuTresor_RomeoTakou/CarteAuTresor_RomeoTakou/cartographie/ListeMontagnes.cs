﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou.cartographie
{
    class ListeMontagnes
    {
        private List<Montagne> listMontagnes = new List<Montagne>();

        public ListeMontagnes() { }
        public void addMontagne(Montagne montagne)
        {
            listMontagnes.Add(montagne);
        }
    }
}
