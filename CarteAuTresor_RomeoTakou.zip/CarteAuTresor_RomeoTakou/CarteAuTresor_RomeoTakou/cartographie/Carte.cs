﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;


namespace CarteAuTresor_RomeoTakou
{
    public sealed class Carte
    {
        private Plaine[,] cases;
        public Carte(int nombreDeLigne, int nombreDeColonne)
        {
            this.cases = new Plaine[nombreDeLigne, nombreDeColonne];
            for(int i = 0; i < nombreDeLigne; i++)
            {
                for (int j = 0; j < nombreDeColonne; j++)
                {
                    this.cases[i,j] = new Plaine();
                }
            }
        }

        public Plaine[,] Cases { get => cases; set => cases = value; }

        public void addMontagne(Montagne m, int ligne, int colonne)
        {
            this.cases[ligne, colonne] = m;
        }
    }
}
