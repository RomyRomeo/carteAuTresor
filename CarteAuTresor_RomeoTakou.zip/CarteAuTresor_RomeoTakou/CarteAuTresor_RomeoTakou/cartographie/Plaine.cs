﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou
{
    public class Plaine
    {
        protected Position position;
        private bool estOccupee;
        protected bool estFranchissable;
        private Tresor tresor;
        public Plaine()
        {
            this.estFranchissable = true;
            this.estOccupee = false;
        }
        public bool EstOccupee { get => estOccupee; set => estOccupee = value; }
        internal Tresor Tresor { get => tresor; set => tresor = value; }
    }
}
