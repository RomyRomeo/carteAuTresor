﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou
{
    public struct Position
    {
        int ligne;
        int colonne;

        public Position(int ligne, int colonne)
        {
            this.ligne = ligne;
            this.colonne = colonne;
        }

        public int Ligne { get => ligne; set => ligne = value; }
        public int Colonne { get => colonne; set => colonne = value; }

        public override string ToString()
        {
            return "[ " + this.Ligne + "," + " " + this.Colonne + " ]";
        }
    }
}
