﻿using CarteAuTresor_RomeoTakou.cartographie;
using CarteAuTresor_RomeoTakou.lireFichier;
using CarteAuTresor_RomeoTakou.parcoursAventuriers;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou.DemarrerApplication
{
    public class Lancer
    {
        static void Main(string[] args)
        {
            Carte carte;
            ListeAventuriers listeAventuriers = new ListeAventuriers();
            ListeMontagnes listeMontagnes = new ListeMontagnes();
            ListeTresors listeTresors = new ListeTresors();
        

            string chemin = @"C:\Workplace\CarteAuTresor_RomeoTakou\CarteAuTresor_RomeoTakou\FichierDEntree\carteAuTresor.txt";
            LecteurFichier lecteur = new LecteurFichier();
            lecteur.lireFichier(chemin);

            carte = lecteur.Carte;
            listeAventuriers = lecteur.ListeAventuriers;
            listeMontagnes = lecteur.ListeMontagnes;
            listeTresors = lecteur.ListeTresors;

           
            
            foreach (Tresor tresor in listeTresors.ListTresors)
            {
                MAJCarte.insererTresor(carte, tresor);
            }
            ParcoursAventurier.deplacementsAventuriers(carte, listeAventuriers.ListAventuriers);

            Console.WriteLine("---------------------------------");
            Console.WriteLine();
            Console.WriteLine();
            foreach ( Aventurier aventurier in listeAventuriers.ListAventuriers)
            {
                Console.WriteLine(aventurier.Nom + " a récolté " + aventurier.TresorsRecoltes + " trésors ");
            }

        }
    }
}
