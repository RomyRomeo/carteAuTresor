﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou
{
    public class Tresor
    {
        private Position position;
        private int occurrence;

        public Tresor() { }
        public Tresor(Position position, int occurrence)
        {
            this.position = position;
            this.occurrence = occurrence;
        }

        public int Occurrence { get => occurrence; set => occurrence = value; }
        internal Position Position { get => position; set => position = value; }
    }
}
