﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarteAuTresor_RomeoTakou
{
    public class ListeTresors
    {
        private List<Tresor> listeTresors = new List<Tresor>();

        public List<Tresor> ListTresors { get => listeTresors; set => listeTresors = value; }

        public void addTresor(Tresor tresor)
        {
            listeTresors.Add(tresor);
        }
    }
}
